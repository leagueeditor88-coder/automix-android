package com.example.automix

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.ServiceConnection
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.MediaStore.Audio.Media
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private var svc: AutomixService? = null
    private var allTracks: List<Track> = emptyList()
    private var tracks: List<Track> = emptyList()
    private var skip = 0
    private var folders: Set<String> = emptySet()
    private var percent = 70
    private var fade = 8

    private lateinit var prefs: SharedPreferences
    private lateinit var nowTitle: TextView
    private lateinit var nowSub: TextView
    private lateinit var pauseBtn: Button
    private lateinit var list: ListView
    private lateinit var folderBtn: Button

    private val audioPerm: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as AutomixService.LocalBinder).service
            s.playPercent = percent
            s.fadeSec = fade
            s.skipIntroSec = skip
            s.onChange = { refreshNow() }
            svc = s
            refreshNow()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("automix", MODE_PRIVATE)
        percent = prefs.getInt("percent", 70)
        fade = prefs.getInt("fade", 8)
        skip = prefs.getInt("skip", 0)
        folders = prefs.getStringSet("folders", emptySet())?.toSet() ?: emptySet()
        buildUi()
        bindService(Intent(this, AutomixService::class.java), conn, BIND_AUTO_CREATE)
        ensurePermissions()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun addSlider(
        root: LinearLayout, lo: Int, hi: Int, value: Int,
        label: (Int) -> String, onValue: (Int) -> Unit
    ) {
        val tv = TextView(this).apply { text = label(value) }
        val sb = SeekBar(this).apply {
            max = hi - lo
            progress = value - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + lo
                    tv.text = label(v)
                    onValue(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(tv)
        root.addView(sb)
    }

    private fun addRow(root: LinearLayout, vararg views: Button) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        views.forEach {
            row.addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(8))
        }
        nowTitle = TextView(this).apply {
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            text = "Automix"
        }
        nowSub = TextView(this).apply {
            textSize = 14f
            text = "Toca una canción o pulsa Automix"
        }
        root.addView(nowTitle)
        root.addView(nowSub)

        pauseBtn = btn("Pausa") { svc?.togglePause() }
        folderBtn = btn("Carpetas: todas") { showFolderDialog() }
        addRow(root, btn("Automix") { startAutomix(-1) }, folderBtn, btn("Stop") { svc?.stopAll() })
        addRow(root, btn("⏮ Anterior") { svc?.previous() }, pauseBtn, btn("Siguiente ⏭") { svc?.next() })

        addSlider(root, 40, 95, percent, { "Reproducir $it% de cada canción" }) {
            percent = it
            svc?.playPercent = it
            prefs.edit().putInt("percent", it).apply()
        }
        addSlider(root, 2, 15, fade, { "Transición: $it segundos" }) {
            fade = it
            svc?.fadeSec = it
            prefs.edit().putInt("fade", it).apply()
        }
        addSlider(root, 0, 45, skip, { if (it == 0) "No saltar intro" else "Saltar los primeros $it s" }) {
            skip = it
            svc?.skipIntroSec = it
            prefs.edit().putInt("skip", it).apply()
        }

        list = ListView(this)
        list.setOnItemClickListener { _, _, position, _ -> startAutomix(position) }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    private fun ensurePermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(audioPerm) != PackageManager.PERMISSION_GRANTED) needed += audioPerm
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) needed += Manifest.permission.POST_NOTIFICATIONS
        if (needed.isEmpty()) loadTracks() else requestPermissions(needed.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        loadTracks()
    }

    private fun loadTracks() {
        if (checkSelfPermission(audioPerm) != PackageManager.PERMISSION_GRANTED) {
            nowSub.text = "Necesito permiso para leer tu música"
            return
        }
        val found = mutableListOf<Track>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.DURATION, Media.DATA)
        contentResolver.query(
            Media.EXTERNAL_CONTENT_URI, proj,
            "${Media.IS_MUSIC} != 0 AND ${Media.DURATION} >= 60000",
            null, "${Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(Media._ID)
            val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
            val iDur = c.getColumnIndexOrThrow(Media.DURATION)
            val iData = c.getColumnIndexOrThrow(Media.DATA)
            while (c.moveToNext()) {
                found += Track(
                    ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, c.getLong(iId)),
                    c.getString(iTitle) ?: "Sin título",
                    c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "Artista desconocido",
                    c.getLong(iDur),
                    c.getString(iData)?.let { File(it).parent } ?: ""
                )
            }
        }
        allTracks = found
        applyFilter()
        if (found.isEmpty()) nowSub.text = "No encontré canciones en el dispositivo"
    }

    private fun applyFilter() {
        val valid = folders.filter { f -> allTracks.any { it.folder == f } }.toSet()
        tracks = if (valid.isEmpty()) allTracks else allTracks.filter { it.folder in valid }
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1,
            tracks.map { "${it.title} — ${it.artist}" }
        )
        folderBtn.text = if (valid.isEmpty()) "Carpetas: todas" else "Carpetas (${valid.size})"
    }

    private fun showFolderDialog() {
        val counts = allTracks.groupingBy { it.folder }.eachCount()
        val paths = counts.keys.sortedBy { it.lowercase() }
        if (paths.isEmpty()) {
            Toast.makeText(this, "No hay carpetas con música", Toast.LENGTH_SHORT).show()
            return
        }
        val names = paths.map { p -> p.substringAfterLast('/').ifEmpty { "/" } + " (" + counts[p] + ")" }.toTypedArray()
        val sel = folders.toMutableSet()
        val checked = BooleanArray(paths.size) { paths[it] in sel }
        AlertDialog.Builder(this)
            .setTitle("Carpetas a mezclar")
            .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                val p = paths[which]
                if (isChecked) sel.add(p) else sel.remove(p)
            }
            .setPositiveButton("Aplicar") { _, _ ->
                folders = sel
                prefs.edit().putStringSet("folders", sel).apply()
                applyFilter()
                Toast.makeText(this, "Se aplica al pulsar Automix", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Todas") { _, _ ->
                folders = emptySet()
                prefs.edit().remove("folders").apply()
                applyFilter()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startAutomix(startAt: Int) {
        if (tracks.isEmpty()) {
            Toast.makeText(this, "No hay canciones cargadas", Toast.LENGTH_SHORT).show()
            return
        }
        startForegroundService(Intent(this, AutomixService::class.java))
        svc?.let {
            it.playPercent = percent
            it.fadeSec = fade
            it.skipIntroSec = skip
            it.start(tracks, startAt)
        }
    }

    private fun refreshNow() {
        val s = svc
        val t = s?.current
        nowTitle.text = t?.title ?: "Automix"
        nowSub.text = t?.artist ?: "Toca una canción o pulsa Automix"
        pauseBtn.text = if (s?.paused == true) "Reanudar" else "Pausa"
    }

    override fun onDestroy() {
        svc?.onChange = null
        try { unbindService(conn) } catch (_: Exception) {}
        super.onDestroy()
    }
}
