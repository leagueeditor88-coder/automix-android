# Automix (Android, open source)

Reproductor de música local con Automix automático:
- Reproduce tu biblioteca local (MediaStore), orden aleatorio.
- Toca cada canción hasta X% (40–95 %, por defecto 70 %) y hace crossfade de 2–15 s (por defecto 8 s) a la siguiente.
- No es mashup: solo hay solapamiento durante la transición.
- Funciona en segundo plano, con notificación (Pausa / Siguiente).
- Botones Anterior / Siguiente, también desde la notificación.
- Opción de saltar la intro (0–45 s) de cada canción.
- Filtro por carpetas: elige de qué carpetas mezclar.
- Los botones activos se resaltan en verde (reproducción, pausa y filtro de carpetas).
- Botón «Detectar BPM actual» para estimar el tempo de la canción en reproducción.
- Incluye análisis aproximado de BPM de la canción que se está reproduciendo (primeros 90 segundos); el resultado es orientativo y aún no sincroniza automáticamente las transiciones con los golpes.
- Sin internet, sin librerías externas. Android 8.0+.

## Compilar sin PC
1. Crea un repositorio en github.com (desde el navegador del móvil, modo escritorio).
2. Sube todos los archivos respetando carpetas (incluida `.github/workflows/build.yml`).
3. Pestaña **Actions** → "Build APK" → Run workflow (o se lanza solo al subir).
4. Al terminar (~3-5 min) descarga el artefacto **Automix-APK**, descomprime e instala `app-debug.apk`.

## Licencia
MIT / a tu elección.


## Búsqueda de género online

El botón «Buscar género online» consulta MusicBrainz por título y artista. Requiere conexión a Internet. Los géneros y etiquetas proceden de la comunidad y pueden faltar o no ser exactos; la app informa cuando no encuentra datos.
